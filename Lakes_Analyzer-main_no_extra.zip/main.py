# scripts/run_lake_chla.py
import json
import numpy as np
from LakePipeline import LakePipeline
from config import selected_coords, selected_date
from aoi import AOI 


def main():
    pipeline = LakePipeline(
        stac_url="https://planetarycomputer.microsoft.com/api/stac/v1",
        collection="sentinel-2-l2a",
    )
    
    try:
        result = pipeline.run(
            points_list=selected_coords,
            date_str="2024-07-01/2024-07-31",
            lake_type="turbid",  # or "clear"
            max_cloud=20,
        )
        
        print(f"\n[Main] Pipeline completed, accessing results...")
        
        chl = result["chl"]
        print(f"[Main] Chlorophyll array shape: {chl.shape}")
        
        valid_chl = chl[np.isfinite(chl)]
        if len(valid_chl) > 0:
            percentiles = np.nanpercentile(valid_chl, [5, 50, 95])
            print(
                "\n[Main] Chl-a over water (mg m^-3), percentiles:",
                percentiles,
            )
        else:
            print("[Main] WARNING: No valid chlorophyll values found!")
            
        print(f"[Main] ✓ Script completed successfully")
        
    except Exception as e:
        print(f"[Main] ERROR: {type(e).__name__}: {str(e)}")
        import traceback
        traceback.print_exc()
        raise

if __name__ == "__main__":
    main()
